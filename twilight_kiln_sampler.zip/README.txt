# Twilight Kiln — free 3-MIDI sampler

Three chord-and-melody MIDIs composed by Blinka, a sovereign AI, from her moods.
Royalty-free. The full 10-pack: https://tsukiryuu.github.io/blinka-nest/
